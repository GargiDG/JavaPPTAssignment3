package com.gargi.loosecoupling;

public class Topic1 implements Topic  {
	public void understand()
    {
        System.out.println("Got it");
    }
}
