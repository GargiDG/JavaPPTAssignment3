package com.gargi.loosecoupling;

public interface Topic
{
    void understand();
}