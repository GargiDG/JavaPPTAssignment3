package com.gargi.loosecoupling;

public class Q5LooseCoupling {

	public static void main(String[] args) {
		Topic t = new Topic1();
        t.understand();

	}

}
