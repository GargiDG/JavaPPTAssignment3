package com.gargi.loosecoupling;

public class Topic2 implements Topic {

	@Override
	public void understand() {
		System.out.println("understand");

	}

}
